# -*- coding: utf-8 -*-
"""
Created on Wed Jan 20 17:50:21 2021

@author: U35220
"""

n = int(input("Enter the number"))
i = 1
sum1 = 0
while i <= n:
    sum1 = sum1 + i
    i = i + 1
print("Sum of first",n,"numbers is", sum1)